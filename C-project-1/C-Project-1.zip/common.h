/*Name : Suraj Roy
Date : 09/08/2022
Decription : Project_1: Steganography
*/
#ifndef COMMON_H
#define COMMON_H

/* Magic string to identify whether stegged or not */
#define MAGIC_STRING "#*"

#endif
